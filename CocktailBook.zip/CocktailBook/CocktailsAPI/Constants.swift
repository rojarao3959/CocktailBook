//
//  Constants.swift
//  CocktailBook
//
//  Created by Rojarao Pothamsetty on 22/11/24.
//

import Foundation

struct Constants {
    
    // Static texts for the HomeView
    struct Home {
        static let filterTitle = "Filter"
        static let allText = "All"
        static let alcoholicText = "Alcoholic"
        static let nonAlcoholicText = "Non-Alcoholic"
        static let loadingText = "Loading cocktails..."
    }
    
    // Static texts for the DetailView
    struct Detail {
        static let ingredientsTitle = "Ingredients:"
        static let minutes = "minutes"
    }
    
    // Static texts for error messages
    struct ErrorMessages {
        static let failedToLoad = "Failed to load cocktails:"
        static let fileNotFound = "JSON file not found."
    }
    
    struct Image {
        static let favorite = "heart.fill"
        static let noFavorite = "heart"
        static let play = "play.fill"
        static let clock = "clock"
    }
}
