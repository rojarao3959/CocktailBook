//
//  HomeViewModalTests.swift
//  CocktailBookTests
//
//  Created by Rojarao Pothamsetty on 22/11/24.
//

import XCTest
@testable import CocktailBook

final class HomeViewModalTests: XCTestCase {
    
    var viewModel : HomeViewModel!

    override func setUpWithError() throws {
        // it will call before each test
        viewModel = HomeViewModel()
    }

    override func tearDownWithError() throws {
        // it will call after each test
        viewModel = nil
    }

    func testFetchCocktails() throws {
        let mockCocktailData: [Cocktail] = [
            Cocktail(id: "1", name: "Mojito", type: "Alcoholic", shortDescription: "A refreshing cocktail", longDescription: "A detailed description", preparationMinutes: 10, imageName: "mojito", ingredients: ["Mint", "Rum"]),
            Cocktail(id: "2", name: "Piña Colada", type: "Alcoholic", shortDescription: "A tropical cocktail", longDescription: "A detailed description", preparationMinutes: 15, imageName: "pina_colada", ingredients: ["Pineapple", "Coconut", "Rum"]),
            Cocktail(id: "3", name: "Margarita mocktail", type: "Alcoholic", shortDescription: "No liquor at all", longDescription: "A detailed description", preparationMinutes: 10, imageName: "mojito", ingredients: ["Mint", "Rum"]),
        ]
        
        viewModel.cocktails = mockCocktailData.map {
            CocktailViewModel(cocktail: $0)
        }
        
        // When: `fetchCocktails()` is called
        viewModel.fetchCocktails()
        
        // Then: Check if the `cocktails` array is populated
        XCTAssertNotNil(viewModel.cocktails, "Cocktails should be populated after fetching data.")
        XCTAssertEqual(viewModel.cocktails?.count, 3)
        XCTAssertEqual(viewModel.cocktails?.first?.cocktail.name, "Mojito")
    }
    
    func testUpdateFavouriteStatus() throws {
        // Given: A HomeViewModel with a cocktail that is not marked as favorite
        let mockCocktail = Cocktail(id: "1", name: "Mojito", type: "Alcoholic", shortDescription: "A refreshing cocktail", longDescription: "A detailed description", preparationMinutes: 10, imageName: "mojito", ingredients: ["Mint", "Rum"])
        let mockCocktailViewModel = CocktailViewModel(cocktail: mockCocktail)
        
        // Set initial state
        XCTAssertFalse(mockCocktailViewModel.isFavorite, "The cocktail should not be marked as favorite initially.")
       
        // When: `updateFavoriteStatus()` is called
        viewModel.updateFavoriteStatus(for: mockCocktailViewModel)
        
        // Now favourite flag will be true
        XCTAssertTrue(mockCocktailViewModel.isFavorite, "The cocktail should be marked as favorite after calling updateFavoriteStatus().")
    }
    
    func testFilteredCocktails() throws {
        // Given: A list of cocktails with different types
        let mockCocktails = [
            Cocktail(id: "1", name: "Mojito", type: "Alcoholic", shortDescription: "A refreshing cocktail", longDescription: "A detailed description", preparationMinutes: 10, imageName: "mojito", ingredients: ["Mint", "Rum"]),
            Cocktail(id: "2", name: "Piña Colada", type: "Alcoholic", shortDescription: "A tropical cocktail", longDescription: "A detailed description", preparationMinutes: 15, imageName: "pina_colada", ingredients: ["Pineapple", "Coconut", "Rum"]),
            Cocktail(id: "3", name: "Lemonade", type: "Non-Alcoholic", shortDescription: "A refreshing drink", longDescription: "A detailed description", preparationMinutes: 5, imageName: "lemonade", ingredients: ["Lemon", "Sugar", "Water"])
        ]
        
        viewModel.cocktails = mockCocktails.map { CocktailViewModel(cocktail: $0) }

        // When: The filter is set to "Alcoholic"
        viewModel.selectedFilter = "Alcoholic"
        
        // Then: Only alcoholic cocktails should be returned
        let filteredCocktails = viewModel.filteredCocktails()
        XCTAssertEqual(filteredCocktails.count, 2, "There should be 2 alcoholic cocktails.")
        XCTAssertTrue(filteredCocktails.allSatisfy { $0.cocktail.type == "Alcoholic" }, "All filtered cocktails should be alcoholic.")
    }

}
