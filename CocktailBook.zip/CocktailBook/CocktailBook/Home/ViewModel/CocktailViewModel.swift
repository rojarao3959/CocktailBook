//
//  CocktailViewModel.swift
//  CocktailBook
//
//  Created by Rojarao Pothamsetty on 22/11/24.
//

import Foundation

class CocktailViewModel: Identifiable, ObservableObject {
    // To track the favorite state
    @Published var isFavorite: Bool
    // Cocktail object
    let cocktail: Cocktail
    
    /// - `Description:` View model  Initaliser
    /// - Parameter data: `cocktail object`
    /// - Parameter isFavorite: `favourite flag`
    init(cocktail: Cocktail, isFavorite: Bool = false) {
        self.isFavorite = isFavorite
        self.cocktail = cocktail
    }
}
